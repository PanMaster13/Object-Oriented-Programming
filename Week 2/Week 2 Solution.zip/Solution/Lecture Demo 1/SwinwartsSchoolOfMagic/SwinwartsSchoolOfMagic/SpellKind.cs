﻿using System;
namespace SwinwartsSchoolOfMagic
{
	public enum SpellKind
	{
		Teleport, Heal, Invisibility
	}
}
