﻿using System;
namespace BankSimulator
{
	public enum AccountType
	{
		Saving, Current, FixedDeposit
	}
}
