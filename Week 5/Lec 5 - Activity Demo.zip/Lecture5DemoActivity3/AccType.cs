﻿using System;
/// <summary>
/// No Longer in Use since different account can be created with specific class.
/// </summary>
namespace Lecture5Demo
{
	public enum AccType
	{
		
	}
}

