﻿using System;

namespace Lecture5Demo
{
	/// <summary>
	/// Remain unchanged
	/// </summary>
	public interface IAccount
	{
		void Deposit (float amt);
		float Withdraw (float amt);
		float Total{ get; set;}
	}
}

