﻿using System;

namespace Lecture5Demo
{
	public class CurrentAccount: IAccount
	{
		private float _total;
		private float _serviceCharge;		// Additional attribute for current account

		//private AccType _type;				//No longer needed since different account can be created with different class.

		public CurrentAccount (float withdrawalCharge)
		{
			_total = 0;
			_serviceCharge = withdrawalCharge;
		}


		public void Deposit(float amt){
			//slightly different way of implementation (assuming service charge applies to perform deposit operation)
			_total = _total + amt - _serviceCharge;
		}

		public float Withdraw(float amt){
			//slightly different way of implementation (assuming service charge applies to perform withdrawal operation)
			_total = _total - amt - _serviceCharge;
			return _total;
		}

		public float Total{
			get{ return _total;}
			set{ _total = value;}
		}

		public float WithdrawalCharge{
			get{ return _serviceCharge;}
			set{ _serviceCharge = value;}
		}
	}
}

