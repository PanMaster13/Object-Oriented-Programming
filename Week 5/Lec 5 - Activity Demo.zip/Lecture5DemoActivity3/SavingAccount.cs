﻿using System;

namespace Lecture5Demo
{
	public class SavingAccount: IAccount
	{
		private float _total;

		//private AccType _type;	//No Longer in Use since different account can be created with specific class.

		public SavingAccount ()
		{
			_total = 0;
		}


		public void Deposit(float amt){
			_total = _total + amt;
		}

		public float Withdraw(float amt){
			_total = _total - amt;
			return _total;
		}

		public float Total{
			get{ return _total;}
			set{ _total = value;}
		}
	}
}

