﻿using System;

namespace Lecture5Demo
{
	/// <summary>
	/// Interface does not contains any attribute
	/// All methods in interface has no implementation
	/// </summary>
	public interface IAccount
	{
		void Deposit (float amt);
		float Withdraw (float amt);
		float Total{ get; set;}
	}
}

