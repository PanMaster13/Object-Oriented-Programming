﻿using System;

namespace Lecture5Demo
{
	/// <summary>
	/// Account can be either Saving Account, Current Account, Fixed Deposit Account.
	/// </summary>
	public class Account: IAccount
	{
		private float _total;
		private AccType _type;
		public Account (AccType type)
		{
			_total = 0;
			_type = type;
		}


		public void Deposit(float amt){
			_total = _total + amt;
		}

		public float Withdraw(float amt){
			_total = _total - amt;
			return _total;
		}

		public float Total{
			get{ return _total;}
			set{ _total = value;}
		}
	}
}

