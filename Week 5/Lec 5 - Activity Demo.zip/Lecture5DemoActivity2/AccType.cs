﻿using System;

namespace Lecture5Demo
{
	public enum AccType
	{
		Saving,
		Current,
		FixedDeposit
	}
}

