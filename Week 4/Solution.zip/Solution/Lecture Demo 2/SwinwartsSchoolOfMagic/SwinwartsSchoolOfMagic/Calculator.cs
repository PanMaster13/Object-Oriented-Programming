﻿using System;
namespace SwinwartsSchoolOfMagic
{
	public class Calculator
	{
		public Calculator(){}

		public int Add(int a, int b)
		{
			int answer = a + b;
			return answer;
		}
	}
}
