﻿using System;

namespace BankSimulator
{
	class MainClass
	{
		public static void Main(string[] args)
		{
		}
	}
}
